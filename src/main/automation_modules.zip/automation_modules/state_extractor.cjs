// src/main/automation_modules/state_extractor.cjs (Revertido para v21)
console.log('[StateExtractor] Módulo carregado.');
const { sleep, randomWait } = require('../utils/helpers.cjs');
/**
 * Função auxiliar para extrair um array JS de uma string de texto.
* [Função extractBalancedArray omitida para brevidade]
 */
function extractBalancedArray(text, startString) {
    const startIndex = text.indexOf(startString);
if (startIndex === -1) {
        console.warn(`[StateExtractor] String inicial "${startString}" não encontrada.`);
        return null;
}
    const arrayStartIndex = text.indexOf('[', startIndex + startString.length);
if (arrayStartIndex === -1) {
        console.warn(`[StateExtractor] Nenhum array '[' encontrado após "${startString}".`);
return null;
    }
    let balance = 0;
    let inString = false;
    let arrayEndIndex = -1;
for (let i = arrayStartIndex; i < text.length; i++) {
        const char = text[i];
if (char === '"' && text[i - 1] !== '\\') { inString = !inString; }
        if (inString) continue;
        if (char === '[') balance++;
        else if (char === ']') balance--;
        if (balance === 0) {
            arrayEndIndex = i + 1;
            break;
        }
   

     }
    if (arrayEndIndex === -1) {
        console.warn(`[StateExtractor] Não foi possível encontrar o ']' de fechamento para "${startString}".`);
        return null;
    }
    return text.substring(arrayStartIndex, arrayEndIndex);
}

/**
 * NOVA FUNÇÃO: Extração de dados da Coleta (Scavenge) usando AJAX e parsing no browser.
 */
async function fetchScavengeData(page, villageId) {
    try {
        // 1. Executa a requisição AJAX e o parsing inicial no contexto do navegador.
    
    const villageObject = await page.evaluate(async (vid) => {
            return new Promise(async (resolve, reject) => {
                const fullUrl = `game.php?village=${vid}&screen=place&mode=scavenge`;
                
                try {
                   
 // ### INÍCIO DA MODIFICAÇÃO (v20) - Correção ParserError ###
                    const response = await jQuery.ajax({
                        url: fullUrl,
                        type: 'GET',
                
        cache: false,
                        dataType: 'text' // MUDADO DE 'json' PARA 'text'
                    });
// Se dataType: 'text', a 'response' é a própria string HTML
                    const htmlContent = response;
if (!htmlContent) {
                         return reject('Conteúdo HTML não encontrado na resposta da Coleta (resposta vazia).');
}
                    // ### FIM DA MODIFICAÇÃO (v20) ###

                    // 2. De volta ao contexto do navegador: Encontra e avalia a variável 'var village'
                    const objectMatch = htmlContent.match(/var\s+village\s+=\s*(\{[\s\S]*?\})\s*;/);
if (objectMatch && objectMatch[1]) {
                        try {
                            const jsString = `(${objectMatch[1]})`;
// eval() é usado para converter a string de objeto JS não-JSON
                            const villageData = eval(jsString);
return resolve(villageData);
                        } catch (e) {
                            return reject('Falha ao avaliar objeto village: ' + e.message);
}
                    }
                    return reject('Objeto village não encontrado no HTML da Coleta.');
} catch (e) {
                    const errorDetail = e.statusText ||
e.responseText || e.message || 'Erro desconhecido';
                    reject(`Falha AJAX na coleta (Status: ${e.status || 'N/A'}): ${String(errorDetail).substring(0, 100)}`);
}
            });
        }, villageId);
        
        return villageObject;
} catch (error) {
        console.error(`[StateExtractor] Erro ao extrair dados de coleta: ${error.message}`);
return null;
    }
}


/**
 * Extrai o estado atual do jogo da página...
 * [Documentação omitida para brevidade]
 */
async function execute(page, sendStatus, config) {
    const accountId = config.accountId;
const villageId = config.villageId;
    let mainUrl = ''; 

    console.log(`[StateExtractor-${accountId}] Iniciando extração de estado para Aldeia ID: 
${villageId}...`);
try {
        // --- PASSO 1: Garantir que estamos na página correta (Nossa 1 Recarga de Página) ---
        const targetUrlPart = `village=${villageId}&screen=main`;
const currentUrl = page.url();

        if (!currentUrl.includes(targetUrlPart)) {
            console.log(`[StateExtractor-${accountId}] URL atual (${currentUrl}) não corresponde a ${targetUrlPart}. Navegando...`);
const baseUrlMatch = currentUrl.match(/^(https?:\/\/[^\/]+)/);
            if (!baseUrlMatch) {
                throw new Error(`Não foi possível determinar a URL base de: ${currentUrl}`);
}
            const baseUrl = baseUrlMatch[1];
            mainUrl = `${baseUrl}/game.php?village=${villageId}&screen=main`;
await page.goto(mainUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
            await page.waitForSelector('#buildings', { timeout: 15000 });
            console.log(`[StateExtractor-${accountId}] Navegação para ${mainUrl} concluída.`);
await randomWait(1000, 3000);
        } else {
            mainUrl = currentUrl.split('?')[0] + `?village=${villageId}&screen=main`;
console.log(`[StateExtractor-${accountId}] Já está na URL correta. Forçando reload para atualizar o estado...`);
            await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
await page.waitForSelector('#buildings', { timeout: 15000 });
            console.log(`[StateExtractor-${accountId}] Reload concluído.`);
            await randomWait(500, 1500);
}
        
        // --- PASSO 2: Extrair game_data (com Cópia Profunda) ---
        let gameData = null;
let attempts = 0;
        while (!gameData && attempts < 3) {
            attempts++;
console.log(`[StateExtractor-${accountId}] Tentativa ${attempts} de extrair game_data...`);
            gameData = await page.evaluate(() => typeof window.game_data !== 'undefined' ? JSON.parse(JSON.stringify(window.game_data)) : null);
if (gameData) break;
            if (attempts < 3) await sleep(1000 * attempts);
}

        // --- Verificação de Robustez Essencial ---
        if (!gameData || !gameData.village || !gameData.player || !gameData.csrf) {
            console.error(`[StateExtractor-${accountId}] FALHA CRÍTICA: game_data ausente ou incompleto.`);
return null; 
        }
        if (String(gameData.village.id) !== String(villageId)) {
             console.error(`[StateExtractor-${accountId}] FALHA CRÍTICA: ID da Aldeia extraído (${gameData.village.id}) não corresponde ao esperado (${villageId}).`);
return null; 
        }
        console.log(`[StateExtractor-${accountId}] game_data extraído com sucesso (Aldeia: ${gameData.village.id}).`);
// --- PASSO 3: Extrair BuildingMain.buildings (Cópia Profunda) ---
        const buildingsData = await page.evaluate(() => typeof window.BuildingMain !== 'undefined' && window.BuildingMain.buildings ? JSON.parse(JSON.stringify(window.BuildingMain.buildings)) : null);
if (buildingsData) {
             console.log(`[StateExtractor-${accountId}] BuildingMain.buildings extraído.`);
} else {
            console.warn(`[StateExtractor-${accountId}] ATENÇÃO: Objeto BuildingMain.buildings não encontrado.`);
}

        // --- PASSO 4 (NOVO): Extrair Missões e Recompensas (via AJAX/Parser) ---
        console.log(`[StateExtractor-${accountId}] Extraindo Missões e Recompensas via AJAX...`);
let completedMissions = [];
        let collectableRewards = [];
        const questUrl = `/game.php?village=${villageId}&screen=new_quests&ajax=quest_popup&tab=main-tab&quest=0`;
        const refererUrl = mainUrl;
try {
            const extractedData = await page.evaluate(async ({ url, referer }) => {
                
                // (Definição da função auxiliar 'extractBalancedArray' colada aqui)
                function extractBalancedArray(text, startString) {
                   

                    const startIndex = text.indexOf(startString);
                    if (startIndex === -1) return null;
                    const arrayStartIndex = text.indexOf('[', startIndex + startString.length);
                    if (arrayStartIndex === -1) return null;
 
                   
                    let balance = 0;
                    let inString = false;
                    let arrayEndIndex = -1;
            
        for (let i = arrayStartIndex; i < text.length; i++) {
                      
                        const char = text[i];
                        if (char === '"' && text[i - 1] !== '\\') 
{ inString = !inString; }
                        if (inString) continue;
if (char === '[') balance++;
   
                         else if (char === ']') balance--;
if (balance === 0) {
                            arrayEndIndex = i + 1;
break;
                        }
                    }
                    if (arrayEndIndex === -1) return null;
return text.substring(arrayStartIndex, arrayEndIndex);
                }
                
                // Início da lógica principal do evaluate
                const missions = [];
const rewards = [];
                try {
                    const response = await fetch(url, {
                        method: 'GET',
                        headers: {
                    

                            'Accept': 'application/json, text/javascript, */*',
                            'TribalWars-Ajax': '1',
                            'X-Requested-With': 'XMLHttpRequest',
           
                 'Referer': referer
  
                         }
                    });
if (!response.ok) {
                        return { missions, rewards, error: `Network error: ${response.statusText}` };
}
                    const data = await response.json();
if (!data || !data.response || !data.response.dialog) {
                        return { missions, rewards, error: "Resposta JSON inválida ou sem 'dialog'."
};
                    }
                    
                    const html = data.response.dialog;
const questArrayString = extractBalancedArray(html, "Questlines.setQuests(");
                    const rewardArrayString = extractBalancedArray(html, "RewardSystem.setRewards(");

                    // Processa Missões (Alvo 1)
                    if (questArrayString) {
                        try {
 

                            const questlines = JSON.parse(questArrayString);
                            for (const questline of questlines) {
                                if (questline.quests && Array.isArray(questline.quests)) 
{
 
                                    for (const quest of questline.quests) {
                                   
                       
  
                                        // ### INÍCIO DA CORREÇÃO (v18) ###
                                        // Extrai TODAS as missões finalizadas (1050, 1055, 1220).
    
                           
                                        if (quest.finished === true && quest.id) {
                           
                 // Usamos 'quest.id' (ex: 1220)
                                     
                                          
  missions.push({ reward_id: String(quest.id) });
                                        }
                                        // ### FIM DA CORREÇÃO (v18) ###
                                   }
             
      
                             }
                            }
                        } catch (e) { 
         
                   console.error("[StateExtractor evaluate] Erro ao parsear Questlines:", e.message);
}
                    }

                    // Processa Recompensas (Alvo 2)
                    if (rewardArrayString) {
                        try {
     
    
                        const rewardData = JSON.parse(rewardArrayString);
for (const rewardData_1 of rewardData) {
                                if (rewardData_1.id && rewardData_1.status === 'unlocked') {
                                    rewards.push({ reward_id: String(rewardData_1.id) });
}
                            }
                        } catch (e) {
                             console.error("[StateExtractor evaluate] Erro ao parsear RewardSystem:", e.message);
}
                    }
                    return { missions, rewards, error: null };
} catch (e) {
                    return { missions: [], rewards: [], error: `Erro fatal no evaluate: ${e.message}` };
}
            }, { url: questUrl, referer: refererUrl });
if (extractedData.error) {
                throw new Error(extractedData.error);
}

            completedMissions = extractedData.missions;
            collectableRewards = extractedData.rewards;
console.log(`[StateExtractor-${accountId}] Missões Principais extraídas: ${completedMissions.length} item(s).`);
            console.log(`[StateExtractor-${accountId}] Recompensas de Construção extraídas: ${collectableRewards.length} item(s).`);
} catch (questError) {
            console.warn(`[StateExtractor-${accountId}] Falha ao executar 'evaluate' de extração (missões/recompensas): ${questError.message}`);
}

        // --- PASSO 5: NOVA EXTRAÇÃO (Scavenger) ---
        console.log(`[StateExtractor-${accountId}] Extraindo dados de Coleta de Recursos...`);
sendStatus('EM_EXECUÇÃO', 'Extraindo dados de Coleta de Recursos...');
        const scavengeData = await fetchScavengeData(page, villageId);
// --- PASSO 6: Extrair Fila de Construção (DOM) --- (Era PASSO 5)
        const constructionQueue = await page.evaluate(() => {
             const queueTable = document.getElementById('build_queue');
             if (!queueTable) return [];
             const rows = queueTable.querySelectorAll('tbody tr[class*="buildorder_"]');
             const queue = [];
    
     
        rows.forEach(row => {
                 try {
                     const buildingMatch = row.className.match(/buildorder_(\w+)/);
                     if (!buildingMatch) return;
                     const buildingId = 
 
                    buildingMatch[1];
                     const nameLevelElement = row.querySelector('td:first-child');
                     let level = 0;
                     if (nameLevelElement) {
         
                const rawText = nameLevelElement.innerText.trim();
 
                         const nameMatch = rawText.match(/^(.+)\s*Nível\s*(\d+)/i);
                         if (nameMatch && nameMatch.length === 3) {
                     
        level = parseInt(nameMatch[2], 10);
}
                     }
                     if (buildingId !== 'unknown' && level > 0) {
                          queue.push({ buildingId: buildingId, level: level });
}
                 } catch(e) { console.error("[StateExtractor evaluate] Erro fila:", e);
}
             });
             return queue;
        });
console.log(`[StateExtractor-${accountId}] Fila de construção extraída: ${constructionQueue.length} item(s).`);


        // --- PASSO 7: Montar o gameState (O OBJETO É CRIADO AQUI) ---
        const gameState = {
            timestamp: Date.now(),
            villageId: gameData.village.id,
            villageName: gameData.village.name,
            village: gameData.village,
            player: gameData.player,
  
   
            buildingsData: buildingsData,
            constructionQueue: constructionQueue,
            csrfToken: gameData.csrf,
            completedMissions: completedMissions,
            collectableRewards: collectableRewards,
            scavengeInfo: scavengeData // <-- DADO ADICIONADO v20
            // (v29) unitManagersData  removido daqui
        };
// Adicionando logs de validação para o novo dado
        if (scavengeData && scavengeData.options) {
             console.log(`[StateExtractor-${accountId}] Dados de Coleta de Recursos extraídos com sucesso.`);
}

        // --- PASSO 8: Normalizar estrutura (para os módulos antigos) ---
        gameState.buildings = gameState.village?.buildings ||
{};
        gameState.resources = {
            wood: gameState.village?.wood ??
0,
            clay: gameState.village?.stone ??
0,
            iron: gameState.village?.iron ??
0,
            storage: { max: gameState.village?.storage_max ??
0 },
        };
gameState.population = {
            current: gameState.village?.pop ??
0,
            max: gameState.village?.pop_max ??
0,
        };

        console.log(`[StateExtractor-${accountId}] Extração de estado completa e VÁLIDA (CSRF: ${gameState.csrfToken ? 'OK' : 'FALHOU'}).`);
sendStatus('EM_EXECUÇÃO', 'Estado do jogo extraído.');
        
        return gameState;

    } catch (error) {
        console.error(`[StateExtractor-${accountId}] Erro GERAL durante a extração de estado:`, error);
sendStatus('FALHA!', `Erro ao extrair estado: ${error.message}`);
        try {
             const screenshotPath = `error_state_extraction_general_${accountId}_${Date.now()}.png`;
await page.screenshot({ path: screenshotPath });
             console.log(`[StateExtractor-${accountId}] Screenshot erro geral salvo: ${screenshotPath}`);
        } catch (ssError) { console.error(`[StateExtractor-${accountId}] Falha screenshot: ${ssError.message}`);
}
        return null; 
    }
}

module.exports = { execute };