// src/main/automation_modules/rewards.cjs (REFATORADO - Padrão AJAX)
const { randomWait } = require('../utils/helpers.cjs');

/**
 * Módulo de Coleta de Recompensas de Construção - Padrão AJAX.
 * Este módulo DEPENDE do 'stateExtractorModule' para popular 
 * o 'gameState.collectableRewards'.
 * @param {import('playwright').Page} page
 * @param {Function} sendStatus - (status, log)
 * @param {object} config - currentConfig
 * @param {object} gameState - O estado atual do jogo (inclui csrfToken e collectableRewards)
 */
async function execute(page, sendStatus, config, gameState) {
    const accountId = config.accountId;
    const villageId = config.villageId;
    const csrfToken = gameState.csrfToken;

    // --- 1. Guards de Validação ---
    if (!csrfToken) {
        console.warn(`[Rewards-${accountId}] gameState não continha token CSRF (h). Pulando.`);
        return;
    }

    const rewardsToCollect = gameState.collectableRewards || [];
    if (rewardsToCollect.length === 0) {
        console.log(`[Rewards-${accountId}] Nenhuma Recompensa de Construção encontrada no gameState. Pulando.`);
        return;
    }

    // --- 2. Loop de Ação (AJAX) ---
    sendStatus('EM_EXECUÇÃO', `Coletando ${rewardsToCollect.length} Recompensas de Construção (via API)...`);

    // Endpoint validado nos logs de inspeção (Network) 
    // É o *mesmo* endpoint do 'missions.cjs'
    const collectUrl = `/game.php?village=${villageId}&screen=new_quests&ajax=claim_reward`;
    const refererUrl = page.url(); // Usar a URL atual como 'Referer'
    let coletadas = 0;
    let falhas = 0;

    try {
        for (const reward of rewardsToCollect) {
            if (!process.connected) return;

            const payload = {
                reward_id: reward.reward_id, // ex: "972919" 
                h: csrfToken
            };
            const bodyPayload = new URLSearchParams(payload).toString();

            console.log(`[Rewards-${accountId}] Disparando fetch() para coletar ID: ${reward.reward_id}`);

            // Executa o fetch de dentro do contexto do browser
            const result = await page.evaluate(async ({ url, bodyString, referer }) => {
                try {
                    const response = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Accept': 'application/json, text/javascript, */*',
                            'TribalWars-Ajax': '1',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Referer': referer
                        },
                        body: bodyString
                    });
                    if (!response.ok) return { error: `Network error: ${response.statusText}` };
                    return await response.json();
                } catch (e) {
                    return { error: `Falha ao parsear resposta (não-JSON): ${e.message}` };
                }
            }, { url: collectUrl, bodyString: bodyPayload, referer: refererUrl });

            // --- 3. Análise Reativa da Resposta ---
            // A resposta de "claimed"  é a nossa confirmação de sucesso
            if (result?.response?.claimed?.id) {
                console.log(`[Rewards-${accountId}] Recompensa ${reward.reward_id} (ID: ${result.response.claimed.id}) coletada com SUCESSO.`);
                coletadas++;
            } else {
                falhas++;
                console.warn(`[Rewards-${accountId}] Servidor recusou a coleta de ${reward.reward_id}:`, JSON.stringify(result));
                
                // Se o usuário [cite: 32] estava correto e a coleta funciona mesmo com armazém cheio,
                // uma falha aqui (response: false) indicaria um erro real (ex: CSRF).
                if (result.error || result.response === false) {
                    const errorMsg = result.error || result.error_message || "Resposta desconhecida";
                    sendStatus('EM_EXECUÇÃO', `Coleta de recompensa falhou (${errorMsg}).`);
                }
            }

            // Ação Anti-Detecção (Humanização de Timing)
            await randomWait(2500, 4500);

        } // Fim do loop for

    } catch (error) {
        console.error(`[Rewards-${accountId}] Erro fatal no loop de coleta de recompensas:`, error);
        sendStatus('FALHA!', `Erro ao coletar recompensas: ${error.message.split('\n')[0]}`);
    } finally {
        if (coletadas > 0) {
            sendStatus('EM_EXECUÇÃO', `Total de ${coletadas} recompensas de construção coletadas.`);
        }
    }
}

module.exports = { execute };