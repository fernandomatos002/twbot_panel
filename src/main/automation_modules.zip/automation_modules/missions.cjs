// src/main/automation_modules/missions.cjs (CORRIGIDO - v19 - Endpoint e Payload Corretos)
const { randomWait } = require('../utils/helpers.cjs');
/**
 * Módulo de Coleta de Missões Principais (Quests) - Padrão AJAX.
 * Este módulo DEPENDE do 'stateExtractorModule' para popular 
 * o 'gameState.completedMissions'.
 * @param {import('playwright').Page} page
 * @param {Function} sendStatus - (status, log)
 * @param {object} config - currentConfig
 * @param {object} gameState - O estado atual do jogo (inclui csrfToken e completedMissions)
 */
async function execute(page, sendStatus, config, gameState) {
    const accountId = config.accountId;
    const villageId = config.villageId;
    const csrfToken = gameState.csrfToken;

    // --- 1. Guards de Validação ---
    if (!csrfToken) {
        console.warn(`[Missions-${accountId}] gameState não continha token CSRF (h). Pulando.`);
        return;
    }

    const missionsToCollect = gameState.completedMissions || [];
    if (missionsToCollect.length === 0) {
        console.log(`[Missions-${accountId}] Nenhuma Missão Principal finalizada encontrada no gameState. Pulando.`);
        return;
    }

    // --- 2. Loop de Ação (AJAX) ---
    sendStatus('EM_EXECUÇÃO', `Coletando ${missionsToCollect.length} Missões Principais (via API)...`);
    const refererUrl = page.url();
    let coletadas = 0;
    let falhas = 0;

    try {
        for (const mission of missionsToCollect) {
            if (!process.connected) return;

            // --- INÍCIO DA CORREÇÃO (v19) ---
            // Baseado na inspeção de rede:
            // 1. O endpoint é 'screen=api' e 'ajaxaction=quest_complete'
            // 2. O ID da quest (ex: 1050) é passado na URL
            const questId = mission.reward_id; // Contém 1050, 1055, 1220
            const collectUrl = `/game.php?village=${villageId}&screen=api&ajaxaction=quest_complete&quest=${questId}&skip=false`;
            
            // 3. O body do POST contém APENAS o token 'h'
            const payload = {
                h: csrfToken
            };
            // --- FIM DA CORREÇÃO (v19) ---

            const bodyPayload = new URLSearchParams(payload).toString();
            console.log(`[Missions-${accountId}] Disparando fetch() para completar Quest ID: ${questId}`);

            // Executa o fetch de dentro do contexto do browser
            const result = await page.evaluate(async ({ url, bodyString, referer }) => {
                try {
                    const response = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Accept': 'application/json, text/javascript, */*',
                            'TribalWars-Ajax': '1',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Referer': referer
                       },
                        body: bodyString
                    });
                    if (!response.ok) return { error: `Network error: ${response.statusText}` };
                    return await response.json();
                } catch (e) {
                    return { error: `Falha ao parsear resposta (não-JSON): ${e.message}` };
                }
            }, { url: collectUrl, bodyString: bodyPayload, referer: refererUrl });

            // --- 3. Análise Reativa da Resposta ---
            // A resposta de sucesso (vista na inspeção) é: {"response": ...}
            // A resposta de falha (vista nos logs) é: {"error": ...}
            if (result.response && !result.error) {
                console.log(`[Missions-${accountId}] Missão ${questId} completada com SUCESSO.`);
                coletadas++;
            } else {
                falhas++;
                console.warn(`[Missions-${accountId}] Servidor recusou a coleta de ${questId}:`, JSON.stringify(result));
                if (result.error || result.response === false) {
                    const errorMsg = result.error || result.error_message || "Resposta desconhecida";
                    sendStatus('EM_EXECUÇÃO', `Coleta de missão falhou (${errorMsg}). Pausando módulo.`);
                }
            }
            await randomWait(2500, 4500);
        } // Fim do loop for

    } catch (error) {
        console.error(`[Missions-${accountId}] Erro fatal no loop de coleta de missões:`, error);
        sendStatus('FALHA!', `Erro ao coletar missões: ${error.message.split('\n')[0]}`);
    } finally {
        if (coletadas > 0) {
            sendStatus('EM_EXECUÇÃO', `Total de ${coletadas} missões principais coletadas.`);
        }
    }
}

module.exports = { execute };