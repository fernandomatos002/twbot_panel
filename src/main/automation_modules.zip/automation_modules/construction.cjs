// src/main/automation_modules/construction.cjs (ATUALIZADO - v27 - Retorna novo estado)
console.log('[Construction] Módulo carregado.');

// (v26) Erro 1 CORRIGIDO: Removido 'require(apiService)'.
// O 'apiService' agora é injetado pelo BotWorker.

// Mapa de Tradução
const BUILDING_ID_MAP = {
    "timber": "wood", 
    "clay": "stone",
    "iron": "iron"
};
function translateBuildingId(inputId) {
    return BUILDING_ID_MAP[inputId] || inputId;
}

// --- (v26) Erro 2 CORRIGIDO: Função Auxiliar: Checa custos ---
// Compara 'currentRes.clay' (do gameState) com 'cost.stone' (do buildingsData).
function checkResources(currentRes, cost) {
    return currentRes.wood >= (cost.wood || 0) && 
           currentRes.clay >= (cost.stone || 0) && // <-- CORRIGIDO AQUI
           currentRes.iron >= (cost.iron || 0);
}
// --- FIM (v26) ---

// (v26) Assinatura atualizada para aceitar 'apiService'
async function execute(page, sendStatus, config, gameState, apiService) {
    const accountId = config.accountId;
    const villageId = config.villageId;
const csrfToken = gameState.csrfToken; 

    if (!csrfToken) {
        console.warn(`[Construction-${accountId}] gameState não continha token CSRF (csrfToken). Pulando.`);
return null; // (v27) Retorna null
    }

    // --- (v25) Validações Essenciais ---
    if (!gameState.buildingsData) {
        console.warn(`[Construction-${accountId}] buildingsData (custos) não encontrado no gameState. Pulando.`);
return null;
    }
    if (!gameState.population || !gameState.resources) {
        console.warn(`[Construction-${accountId}] population ou resources não encontrado no gameState. Pulando.`);
return null;
    }

    // --- PASSO 1: Verificar Fila de Construção ---
    const queue = gameState.constructionQueue ||
[];
    const MAX_QUEUE = 2; 
    if (queue.length >= MAX_QUEUE) {
        console.log(`[Construction-${accountId}] Fila de construção cheia (${queue.length}/${MAX_QUEUE}). Aguardando.`);
return null;
    }

    // --- (v25) INÍCIO DA NOVA LÓGICA DE PRIORIDADE ---
    
    let nextItem = null; // O que vamos construir
    const currentRes = gameState.resources;
    const currentBuildings = gameState.buildings; // Níveis atuais (ex: "wood": "11") 
    const pop = gameState.population;
    
    // --- (v25) PRIORIDADE 1: FAZENDA ---
    const popUsage = pop.current / pop.max;
    if (config.auto_farm_enabled && popUsage >= 0.80) {
        console.log(`[Construction-${accountId}] PRIORIDADE: Fazenda (População em ${Math.round(popUsage * 100)}%)...`);
        const farmCost = gameState.buildingsData.farm; // Custo para o *próximo* nível
        
        if (farmCost && checkResources(currentRes, farmCost)) {
            const currentLevel = parseInt(currentBuildings.farm || "0", 10);
            nextItem = { id: 'farm', level: currentLevel + 1 };
            console.log(`[Construction-${accountId}] -> Enviando Fazenda Nv. ${nextItem.level}.`);
        } else if (farmCost) {
            console.log(`[Construction-${accountId}] -> População alta, mas sem recursos para Fazenda.`);
        } else {
            console.warn(`[Construction-${accountId}] -> População alta, mas 'buildingsData.farm' não encontrado.`);
        }
    }

    // --- (v25) PRIORIDADE 2: ARMAZÉM (Se a Fazenda não foi acionada) ---
    if (!nextItem && config.auto_warehouse_enabled && config.constructionListId) {
        // (v26) Passa o 'apiService' injetado para o helper
        const nextListItem = await getNextItemFromList(accountId, config.constructionListId, currentBuildings, queue, apiService);
        
        if (nextListItem) {
            const itemCost = gameState.buildingsData[nextListItem.id];
            if (!itemCost) {
                 console.warn(`[Construction-${accountId}] PRIORIDADE: Armazém. Próximo item (${nextListItem.id}) não tem dados de custo.`);
            } else {
                const maxStorage = currentRes.storage.max;
                if (itemCost.wood > maxStorage || itemCost.stone > maxStorage || itemCost.iron > maxStorage) {
                    console.log(`[Construction-${accountId}] PRIORIDADE: Armazém (Próximo item '${nextListItem.id}' custa mais que ${maxStorage})...`);
                    
                    const storageCost = gameState.buildingsData.storage; // Custo do *próximo* armazém
                    if (storageCost && checkResources(currentRes, storageCost)) {
                        const currentLevel = parseInt(currentBuildings.storage || "0", 10);
                        nextItem = { id: 'storage', level: currentLevel + 1 };
                        console.log(`[Construction-${accountId}] -> Enviando Armazém Nv. ${nextItem.level}.`);
                    } else if (storageCost) {
                        console.log(`[Construction-${accountId}] -> Armazém necessário, mas sem recursos para evoluí-lo.`);
                    } else {
                         console.warn(`[Construction-${accountId}] -> Armazém necessário, mas 'buildingsData.storage' não encontrado.`);
                    }
                }
            }
        }
    }

    // --- (v25) LÓGICA PADRÃO: LISTA DE CONSTRUÇÃO (Se nenhuma prioridade foi acionada) ---
    if (!nextItem && config.constructionListId) {
        console.log(`[Construction-${accountId}] Buscando item na Lista de Construção...`);
        // (v26) Passa o 'apiService' injetado para o helper
        nextItem = await getNextItemFromList(accountId, config.constructionListId, currentBuildings, queue, apiService);
        
        if (nextItem) {
             console.log(`[Construction-${accountId}] Próximo objetivo da lista: ${nextItem.id} Nv. ${nextItem.level}`);
        } else {
            console.log(`[Construction-${accountId}] Lista de construção concluída (ou todos os itens estão na fila).`);
        }
    } else if (!nextItem && !config.constructionListId) {
         console.log(`[Construction-${accountId}] Nenhuma lista de construção associada. Pulando.`);
    }

    // --- (v25) FIM DA NOVA LÓGICA ---

    if (!nextItem) {
return null; // Nada para construir
    }
    
    // --- PASSO 4.5: VERIFICAR RECURSOS PARA O 'nextItem' (Seja da prioridade ou lista) ---
    const buildingId = nextItem.id;
const buildingData = gameState.buildingsData ?
gameState.buildingsData[buildingId] : null;

    if (!buildingData) {
        console.warn(`[Construction-${accountId}] Não foi possível encontrar dados de custo (buildingsData) para ${buildingId}. Pulando verificação (deixando o servidor decidir).`);
} else {
        if (!checkResources(currentRes, buildingData)) {
            console.log(`[Construction-${accountId}] Recursos insuficientes (local) para ${buildingId} Nv. ${nextItem.level}. Pulando.`);
console.log(`[Construction-${accountId}] -> Custo: W:${buildingData.wood || 0} C:${buildingData.stone || 0} I:${buildingData.iron || 0}`);
            console.log(`[Construction-${accountId}] -> Atual: W:${Math.floor(currentRes.wood)} C:${Math.floor(currentRes.clay)} I:${Math.floor(currentRes.iron)}`);
            return null;
// Impede a requisição fetch()
        }
        
        console.log(`[Construction-${accountId}] Recursos suficientes (local) detectados. Enviando requisição...`);
}
    // --- FIM DA VERIFICAÇÃO DE RECURSOS ---

    // --- PASSO 5: EXECUTAR AÇÃO DE CONSTRUÇÃO (OTIMIZADA) ---
    try {
        const buildUrl = `/game.php?village=${villageId}&screen=main&ajaxaction=upgrade_building&type=main`;
const refererUrl = page.url(); 
        const payload = {
            id: nextItem.id,
            force: "1",
            destroy: "0",
            source: villageId,
            h: csrfToken
        };
const bodyPayload = new URLSearchParams(payload).toString();

        console.log(`[Construction-${accountId}] Disparando fetch() para: ${buildUrl} com ID: ${nextItem.id}`);
const result = await page.evaluate(async ({ url, bodyString, referer }) => {
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
             
           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 
                        'Accept': 'application/json, text/javascript, */*',
                        'TribalWars-Ajax': '1',
                        'X-Requested-With': 'XMLHttpRequest',
         
               'Referer': referer
                    },
                    body: bodyString 
                });
                
          
      if (!response.ok) {
                    return { error: `Network error: ${response.statusText}` };
                }
                
                return await response.json();
            } catch (e) {
 
               return { error: `Falha ao parsear resposta (não-JSON): ${e.message}` };
            }
        }, { url: buildUrl, bodyString: bodyPayload, referer: refererUrl });

        // --- (v27) INÍCIO DA CORREÇÃO ---
        // Lógica de verificação de sucesso (baseada no 'recruitment.cjs')
        if (result?.response?.success && result?.game_data?.village) { 
            console.log(`[Construction-${accountId}] Requisição fetch() para construir ${nextItem.id} BEM-SUCEDIDA.`);
            return result.game_data.village; // <-- RETORNA O NOVO ESTADO
            
        } else if (result?.response?.success) {
            // Sucesso, mas sem game_data (fallback)
            console.log(`[Construction-${accountId}] Requisição fetch() para construir ${nextItem.id} BEM-SUCEDIDA (sem game_data).`);
            return null;
            
        } else {
            // Se não for sucesso, loga a falha
            console.warn(`[Construction-${accountId}] Servidor recusou a construção:`, JSON.stringify(result));
if (result?.error) {
                 console.log(`[Construction-${accountId}] Motivo (explícito): ${result.error}`);
} else if (result?.response === false) {
                 console.log(`[Construction-${accountId}] Motivo: O servidor retornou 'response: false'. (Verificar pré-requisitos ou fila no jogo).`);
} else if (result?.game_data?.csrf && result.game_data.csrf !== csrfToken) {
                 console.error(`[Construction-${accountId}] FALHA DE CSRF: Token enviado é diferente do recebido.`);
} else {
                 console.log(`[Construction-${accountId}] Motivo: Resposta inesperada do servidor.`);
}
            return null;
        }
        // --- (v27) FIM DA CORREÇÃO ---

    } catch (error) {
        console.error(`[Construction-${accountId}] Erro ao executar buildWithFetch: ${error.message}`);
}
    
    return null; // Retorno padrão em caso de falha no try/catch
}


/**
 * (v26) Função Auxiliar Atualizada: Aceita 'apiService'
 * (Extraída da lógica principal para reutilização)
 */
async function getNextItemFromList(accountId, listId, currentBuildings, queue, apiService) {
    let constructionList;
    try {
        // (v26) Usa a instância injetada do apiService
        console.log(`[Construction-${accountId}] (Helper) Buscando Lista ID: ${listId} no servidor...`);
const response = await apiService.get(`/api/construction-lists/${listId}`);
        if (!response.data?.success || !response.data.list) {
            throw new Error('API do VPS não retornou uma lista de construção válida.');
}
        constructionList = response.data.list;
if (!constructionList.steps || !Array.isArray(constructionList.steps)) {
            console.warn(`[Construction-${accountId}] (Helper) Lista '${constructionList.name}' foi encontrada, mas não contém 'steps'.`);
return null;
        }
    } catch (error) {
        console.error(`[Construction-${accountId}] (Helper) Falha ao buscar lista de construção:`, error.message);
return null;
    }

    // Lógica original de busca
    for (const item of constructionList.steps) {
        const building = translateBuildingId(item.buildingId);
const targetLevel = parseInt(item.level, 10);
        const currentLevel = parseInt(currentBuildings[building] || "0", 10);
if (currentLevel < targetLevel) {
            // Verifica se o Nível (currentLevel + 1) já está na fila
            const inQueue = queue.some(q => q.buildingId === building && q.level === (currentLevel + 1));
if (inQueue) {
                continue;
}
            return { id: building, level: currentLevel + 1 }; // Encontrou!
}
    }

    return null; // Lista concluída
}

module.exports = { execute };