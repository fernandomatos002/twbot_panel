// src/main/automation_modules/scavenger.cjs
// Lógica V13: Correção da Detecção de Sucesso (Coerção de Tipo)
const { randomWait } = require('../utils/helpers.cjs');

// --- CONSTANTES DE ENGENHARIA (Custos e Pesos) ---
const WEIGHTS = {
    "1": 15, // Pequena
    "2": 6,  // Média
    "3": 3,  // Grande
    "4": 2   // Extrema
};
const MIN_INFANTRY_TO_SCAVENGE = 10; // Mínimo de infantaria (lanças + espadas) para enviar
const CARRY_CAPACITY = {
    spear: 25,
    sword: 15
};

// Custos de desbloqueio confirmados (madeira, pedra, ferro)
const UNLOCK_COSTS = {
    "1": { wood: 25, stone: 30, iron: 25 },
    "2": { wood: 250, stone: 300, iron: 250 },
    "3": { wood: 1000, stone: 1200, iron: 1000 },
    "4": { wood: 10000, stone: 12000, iron: 10000 }
};

/**
 * Módulo de Coleta (Scavenger) - Padrão AJAX
 * @returns {Object|null} Retorna o NOVO objeto village (scavengeInfo) se uma ação for bem-sucedida, senão null.
 */
async function execute(page, sendStatus, config, gameState) {
    const accountId = config.accountId;
    const villageId = config.villageId;
    const csrfToken = gameState.csrfToken;
    
    // (v12) Esta variável irá armazenar o estado mais recente retornado pelo servidor
    let newScavengeState = null; 

    // --- 1. Guards de Validação ---
    if (!csrfToken) {
        console.warn(`[Scavenger-${accountId}] gameState não continha token CSRF (h). Pulando.`);
        return newScavengeState;
    }
    
    const scavengeInfo = gameState.scavengeInfo;
    const currentRes = gameState.resources; 
    
    if (!scavengeInfo || !scavengeInfo.options) {
        console.log(`[Scavenger-${accountId}] Nenhuma informação de Coleta (scavengeInfo) encontrada no gameState. Pulando.`);
        return newScavengeState;
    }
    
    const options = scavengeInfo.options;
    const troopsAvailable = scavengeInfo.unit_counts_home || {};
    
    // (v11) Cálculo de Tropas
    const totalSpears = troopsAvailable.spear || 0;
    const totalSwords = troopsAvailable.sword || 0;
    const totalInfantryPool = totalSpears + totalSwords;

    try {
        // --- 2. Lógica de Ação Prioritária (Desbloqueio) ---
        let unlockedSomething = false;
        for (const optionId in options) {
            const option = options[optionId];
            const costs = UNLOCK_COSTS[optionId];

            if (option.is_locked === true && option.unlock_time === null) {
                if (unlockedSomething) continue;
                if (!checkResourcesForUnlock(accountId, currentRes, costs, optionId)) {
                    continue; 
                }

                sendStatus('EM_EXECUÇÃO', `Iniciando desbloqueio da Coleta (ID: ${optionId})...`);
                
                // (v12) Captura de estado
                const unlockResult = await unlockScavengeOption(page, config, csrfToken, optionId);
                
                if (unlockResult) {
                    unlockedSomething = true;
                    newScavengeState = unlockResult; // Captura o novo estado
                }
            }
        }
        
        if (unlockedSomething) {
            console.log(`[Scavenger-${accountId}] Ação de desbloqueio iniciada. Continuando para envio...`);
        }

        // --- 3. Lógica de Ação Secundária (Envio Dinâmico) ---
        
        const freeSlots = [];
        for (const optionId in options) {
            // (v12) Usa o 'newScavengeState' se ele existir (foi atualizado), senão usa o 'options' original
            const currentOptions = newScavengeState ? (newScavengeState.options || options) : options;
            const opt = currentOptions[optionId];
            
            if (opt.scavenging_squad === null && opt.is_locked === false) {
                freeSlots.push(optionId);
            }
        }

        if (freeSlots.length === 0 || totalInfantryPool < MIN_INFANTRY_TO_SCAVENGE) {
            console.log(`[Scavenger-${accountId}] Nenhuma ação de envio necessária (Livres: ${freeSlots.length}, Infantaria: ${totalInfantryPool}).`);
            return newScavengeState; // Retorna o estado (se houver) do desbloqueio
        }

        sendStatus('EM_EXECUÇÃO', `Calculando alocação para ${freeSlots.length} slots livres com ${totalInfantryPool} infantaria...`);
        
        let totalWeight = 0;
        for (const optionId of freeSlots) {
            totalWeight += WEIGHTS[optionId] || 0;
        }

        if (totalWeight === 0) {
            console.warn(`[Scavenger-${accountId}] Erro no cálculo de peso (totalWeight = 0). Pulando.`);
            return newScavengeState;
        }

        // (v11) Alocação Proporcional
        const spearProportion = totalSpears / totalInfantryPool;
        const swordProportion = totalSwords / totalInfantryPool;

        let spearsAllocated = 0;
        let swordsAllocated = 0;
        const troopsToAllocate = {};
        
        for (let i = 0; i < freeSlots.length - 1; i++) {
            const optionId = freeSlots[i];
            const totalTroopsForSlot = Math.floor(totalInfantryPool * (WEIGHTS[optionId] / totalWeight));
            const spearsForSlot = Math.floor(totalTroopsForSlot * spearProportion);
            const swordsForSlot = totalTroopsForSlot - spearsForSlot;
            
            troopsToAllocate[optionId] = { spear: spearsForSlot, sword: swordsForSlot };
            spearsAllocated += spearsForSlot;
            swordsAllocated += swordsForSlot;
        }
        
        const lastSlotId = freeSlots[freeSlots.length - 1];
        troopsToAllocate[lastSlotId] = {
            spear: totalSpears - spearsAllocated,
            sword: totalSwords - swordsAllocated
        };
        
        // Enviar os esquadrões
        for (const optionId in troopsToAllocate) {
            const troops = troopsToAllocate[optionId];
            const carryCapacity = (troops.spear * CARRY_CAPACITY.spear) + (troops.sword * CARRY_CAPACITY.sword);
            
            if (troops.spear > 0 || troops.sword > 0) {
                console.log(`[Scavenger-${accountId}] Enviando ${troops.spear} lanças e ${troops.sword} espadas para Opção ${optionId}.`);
                
                // (v12) Captura de estado
                const sendResult = await sendScavengeSquad(page, config, csrfToken, optionId, troops, carryCapacity);
                if (sendResult) {
                    newScavengeState = sendResult; // Captura o novo estado (sobrescreve o anterior)
                }
                
                await randomWait(500, 1500);
            }
        }
        
        sendStatus('EM_EXECUÇÃO', `Esquadrões dinâmicos enviados.`);
        return newScavengeState; // Retorna o estado final

    } catch (error) {
        console.error(`[Scavenger-${accountId}] Erro fatal no loop de coleta:`, error);
        sendStatus('FALHA!', `Erro na coleta: ${error.message.split('\n')[0]}`);
        return newScavengeState; // Retorna o que tiver
    }
}


/**
 * Verifica se a aldeia tem recursos suficientes para o desbloqueio.
 */
function checkResourcesForUnlock(accountId, currentRes, costs, optionId) {
    // (Código inalterado)
    if (currentRes.wood < costs.wood || currentRes.clay < costs.stone || currentRes.iron < costs.iron) {
        console.log(`[Scavenger-${accountId}] Recursos insuficientes para desbloquear Opção ${optionId}. Pulando.`);
        console.log(`[Scavenger-${accountId}] -> Custo: W:${costs.wood} C:${costs.stone} I:${costs.iron}`);
        console.log(`[Scavenger-${accountId}] -> Atual: W:${Math.floor(currentRes.wood)} C:${Math.floor(currentRes.clay)} I:${Math.floor(currentRes.iron)}`);
        return false;
    }
    console.log(`[Scavenger-${accountId}] Recursos suficientes para desbloquear Opção ${optionId}.`);
    return true;
}


// --- Funções Auxiliares (Unlock e Send Squad) ---

/**
 * Tenta desbloquear uma opção de coleta.
 * @returns {Object|null} Retorna o NOVO objeto village (scavengeInfo) se sucesso, senão null.
 */
async function unlockScavengeOption(page, config, csrfToken, optionId) {
    // (Código v12 inalterado)
    const url = `/game.php?village=${config.villageId}&screen=scavenge_api&ajaxaction=start_unlock`;
    const payload = {
        village_id: config.villageId,
        option_id: optionId,
        h: csrfToken
    };
    const bodyPayload = new URLSearchParams(payload).toString();
    const refererUrl = page.url();

    console.log(`[Scavenger-${config.accountId}] Disparando fetch() para Desbloquear ID: ${optionId}`);
    
    const result = await page.evaluate(async ({ url, bodyString, referer }) => {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept': 'application/json, text/javascript, */*',
                    'TribalWars-Ajax': '1',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Referer': referer
                },
                body: bodyString
            });
            if (!response.ok) return { error: `Network error: ${response.statusText}` };
            return await response.json();
        } catch (e) {
            return { error: `Falha ao parsear resposta (não-JSON): ${e.message}` };
        }
    }, { url, bodyString: bodyPayload, referer: refererUrl });

    if (result.response && result.response.village) {
        console.log(`[Scavenger-${config.accountId}] Desbloqueio da opção ${optionId} iniciado (confirmado pelo servidor).`);
        return result.response.village; 
    } else {
        console.warn(`[Scavenger-${config.accountId}] Servidor recusou o desbloqueio de ${optionId} (ou resposta inesperada):`, JSON.stringify(result));
        return null; 
    }
}

/**
 * Envia um esquadrão de coleta.
 * @returns {Object|null} Retorna o NOVO objeto village (scavengeInfo) se sucesso, senão null.
 */
async function sendScavengeSquad(page, config, csrfToken, optionId, troops, carryCapacity) {
    const url = `/game.php?village=${config.villageId}&screen=scavenge_api&ajaxaction=send_squads`;
    
    // (Payload v11 inalterado)
    const payload = {
        'squad_requests[0][village_id]': config.villageId,
        'squad_requests[0][option_id]': optionId,
        'squad_requests[0][use_premium]': 'false',
        'squad_requests[0][candidate_squad][unit_counts][spear]': troops.spear || 0,
        'squad_requests[0][candidate_squad][unit_counts][sword]': troops.sword || 0,
        'squad_requests[0][candidate_squad][unit_counts][axe]': 0,
        'squad_requests[0][candidate_squad][unit_counts][archer]': 0,
        'squad_requests[0][candidate_squad][unit_counts][light]': 0,
        'squad_requests[0][candidate_squad][unit_counts][marcher]': 0,
        'squad_requests[0][candidate_squad][unit_counts][heavy]': 0,
        'squad_requests[0][candidate_squad][unit_counts][knight]': 0,
        'squad_requests[0][candidate_squad][carry_max]': carryCapacity,
        'h': csrfToken
    };

    const bodyPayload = new URLSearchParams(payload).toString();
    const refererUrl = page.url(); 

    console.log(`[Scavenger-${config.accountId}] Disparando fetch() para Enviar Coleta ID: ${optionId}`);

    const result = await page.evaluate(async ({ url, bodyString, referer }) => {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept': 'application/json, text/javascript, */*',
                    'TribalWars-Ajax': '1',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Referer': referer
                },
                body: bodyString
            });
            if (!response.ok) return { error: `Network error: ${response.statusText}` };
            return await response.json();
        } catch (e) {
            return { error: `Falha ao parsear resposta (não-JSON): ${e.message}` };
        }
    }, { url, bodyString: bodyPayload, referer: refererUrl });

 // ### INÍCIO DA MODIFICAÇÃO (v14) - Correção da Verificação de Sucesso (Lógica Robusta) ###
    // A verificação 'squad_responses' não é confiável.
    // A verificação confiável (como no 'unlock') é se o servidor retornou o novo estado da aldeia.
    if (result.response && result.response.villages && result.response.villages[config.villageId]) {
    // ### FIM DA MODIFICAÇÃO (v14) ###
        console.log(`[Scavenger-${config.accountId}] Esquadrão (ID: ${optionId}) enviado com sucesso.`);
        // Retorna o novo estado da aldeia específica
        return result.response.villages[config.villageId] || null;
    } else {
        console.warn(`[Scavenger-${config.accountId}] Servidor recusou o envio para ${optionId}:`, JSON.stringify(result));
        return null;
    }
}


module.exports = { execute };