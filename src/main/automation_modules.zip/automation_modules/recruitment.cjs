// src/main/automation_modules/recruitment.cjs
// (v40) - CORRIGIDO: Adiciona tropas 'coletando' (lidas do scavengeInfo.options) ao cálculo total.
console.log('[Recruitment] Módulo carregado.');

const { randomWait } = require('../utils/helpers.cjs');
const cheerio = require('cheerio'); // (v33) Requerido para ler o HTML

// --- Constantes de Engenharia ---
const RESOURCE_BUFFER_PERCENTAGE = 0.40; // 40%
const RECRUITABLE_UNITS = [
    'spear', 'sword', 'axe', 'archer', 
    'spy', 'light', 'marcher', 'heavy', 
    'ram', 'catapult', 'knight'
];

// (v33) Mapa de qual edifício constrói qual unidade
const UNIT_BUILDING_MAP = {
    spear: 'barracks', sword: 'barracks', axe: 'barracks', archer: 'barracks',
    spy: 'stable', light: 'stable', marcher: 'stable', heavy: 'stable', knight: 'stable',
    ram: 'garage', catapult: 'garage'
};

// (v33) Regra do usuário
const MAX_QUEUE_PER_BUILDING = 2;

// --- (v29) CUSTOS FIXOS DAS UNIDADES ---
const UNIT_COSTS = {
    spear:    { wood: 50,  stone: 30,  iron: 10,  pop: 1 }, // Lanceiro
    sword:    { wood: 30,  stone: 30,  iron: 70,  pop: 1 }, // Espadachim
    axe:      { wood: 60,  stone: 30,  iron: 40,  pop: 1 }, // Bárbaro
    spy:      { wood: 50,  stone: 50,  iron: 20,  pop: 2 }, // Explorador
    light:    { wood: 125, stone: 100, iron: 250, pop: 4 }, // Cavalaria leve
    heavy:    { wood: 200, stone: 150, iron: 600, pop: 6 }, // Cavalaria pesada
    ram:      { wood: 300, stone: 200, iron: 200, pop: 5 }, // Aríete
    catapult: { wood: 320, stone: 400, iron: 100, pop: 8 }, // Catapulta
    
    archer:   { wood: 0, stone: 0, iron: 0, pop: 0 }, // TODO
    marcher:  { wood: 0, stone: 0, iron: 0, pop: 0 }, // TODO
    knight:   { wood: 0, stone: 0, iron: 0, pop: 0 }  // TODO
};
// --- FIM (v29) ---

// --- (v40) Funções de Parse Corrigidas ---

/**
 * (v38) Conta a FILA (tr[id^="trainorder_"])
 * e soma a FILA + PRODUÇÃO (tr.lit)
 */
function parseRecruitmentQueue(htmlContent) {
    const $ = cheerio.load(htmlContent);
    const queueUnits = {}; // Soma total de unidades (ex: {spear: 50})
    const queueLengths = { barracks: 0, stable: 0, garage: 0 }; // Contagem de itens (ex: {barracks: 2})
    
    const queueIdsMap = {
        'trainqueue_barracks': 'barracks',
        'trainqueue_stable': 'stable',
        'trainqueue_garage': 'garage'
    };

    for (const [queueId, buildingName] of Object.entries(queueIdsMap)) {
        
        // (v38) Seletor para a FILA (itens esperando)
        const rows = $(`tbody#${queueId} tr[id^="trainorder_"]`);
        
        queueLengths[buildingName] = rows.length;

        // Soma tropas NA FILA
        rows.each((i, row) => {
             try {
                 const unitElement = $(row).find('div.unit_sprite');
                 if (unitElement.length === 0) return;
                 const unitId = unitElement.attr('class').split(' ').pop();
                 if (!RECRUITABLE_UNITS.includes(unitId)) return;
                 const text = $(row).find('td').first().text().trim();
                 const amountMatch = text.match(/^(\d+)/);
                 if (unitId && amountMatch) {
                     const amount = parseInt(amountMatch[1], 10);
                     queueUnits[unitId] = (queueUnits[unitId] || 0) + amount;
                 }
            } catch (e) {
                 console.warn(`[Recruitment] Erro ao fazer parse de uma linha da fila: ${e.message}`);
            }
        });
        
        // (v38) Adiciona o item em PRODUÇÃO (tr.lit)
        const wrapperSelector = `div#${queueId.replace('trainqueue_', 'trainqueue_wrap_')}`;
        const inProductionRow = $(`${wrapperSelector} tr.lit`);
        if (inProductionRow.length > 0) {
            try {
                const unitElement = inProductionRow.find('div.unit_sprite');
                const unitId = unitElement.length > 0 ? unitElement.attr('class').split(' ').pop() : null;
                const text = inProductionRow.find('td').first().text().trim();
                const amountMatch = text.match(/^(\d+)/);
                
                if (unitId && amountMatch && RECRUITABLE_UNITS.includes(unitId)) {
                    const amount = parseInt(amountMatch[1], 10);
                    queueUnits[unitId] = (queueUnits[unitId] || 0) + amount;
                }
            } catch (e) {
                 console.warn(`[Recruitment] Erro ao fazer parse da linha em produção (tr.lit): ${e.message}`);
            }
        }
    }
    return { units: queueUnits, lengths: queueLengths };
}

/**
 * (v40) NOVA FUNÇÃO: Calcula o total de tropas que estão coletando.
 * Lê o scavengeInfo.options.
 */
function calculateScavengingTroops(scavengeOptions) {
    const scavengingTroops = {};
    if (!scavengeOptions || typeof scavengeOptions !== 'object') {
        return scavengingTroops;
    }

    // Loop pelos IDs das opções (ex: "1", "2", "3", "4")
    for (const optionId in scavengeOptions) {
        const option = scavengeOptions[optionId];
        // Verifica se um esquadrão está fora (scavenging_squad não é nulo)
        if (option.scavenging_squad && option.scavenging_squad.unit_counts) {
            const units = option.scavenging_squad.unit_counts;
            // Soma as unidades desse esquadrão
            for (const unitId in units) {
                if (units.hasOwnProperty(unitId) && RECRUITABLE_UNITS.includes(unitId)) {
                    scavengingTroops[unitId] = (scavengingTroops[unitId] || 0) + units[unitId];
                }
            }
        }
    }
    return scavengingTroops;
}
// --- FIM (v40) ---


function calculateProportionalBatch(deficit, resources, unitCosts) {
    // (Lógica v24 inalterada)
    let totalCost = { wood: 0, clay: 0, iron: 0, pop: 0 };
    for (const unitId in deficit) {
         const amount = deficit[unitId];
         const cost = unitCosts[unitId];
         if (cost) {
             totalCost.wood += cost.wood * amount;
             totalCost.clay += cost.stone * amount; 
             totalCost.iron += cost.iron * amount;
             totalCost.pop += cost.pop * amount;
         }
    }
    if (totalCost.wood === 0 && totalCost.clay === 0 && totalCost.iron === 0) {
         return {}; 
    }
    let bottleneck = 1.0; 
    if (totalCost.wood > 0) bottleneck = Math.min(bottleneck, resources.wood / totalCost.wood);
    if (totalCost.clay > 0) bottleneck = Math.min(bottleneck, resources.clay / totalCost.clay);
    if (totalCost.iron > 0) bottleneck = Math.min(bottleneck, resources.iron / totalCost.iron);
    if (totalCost.pop > 0)  bottleneck = Math.min(bottleneck, resources.pop / totalCost.pop);
    if (bottleneck <= 0) {
         return {};
    }
    const batch = {};
    for (const unitId in deficit) {
         const amountNeeded = deficit[unitId];
         const amountToRecruit = Math.floor(amountNeeded * bottleneck);
         if (amountToRecruit > 0) {
             batch[unitId] = amountToRecruit;
         }
    }
    return batch;
}


/**
 * Módulo de Recrutamento (Alvo de Tropas)
 * @returns {Object|null} Retorna o novo objeto village (game_data.village) se uma ação for bem-sucedida.
 */
async function execute(page, sendStatus, config, gameState) {
    const accountId = config.accountId;
    const villageId = config.villageId;
    const csrfToken = gameState.csrfToken; 
    
    // --- 1. Guards de Validação ---
    const targetTemplate = config.recruitmentTemplate;
    if (!targetTemplate || Object.keys(targetTemplate).length === 0) {
         console.log(`[Recruitment-${accountId}] Nenhum "Alvo de Tropas" (template) definido. Pulando.`);
         return null;
    }
    
    if (!gameState.village || !gameState.resources || !gameState.population) {
          console.warn(`[Recruitment-${accountId}] gameState inválido (sem village, resources ou population). Pulando.`);
          return null;
    }
    
    // --- (v40) INÍCIO DA CORREÇÃO ---
    // 2. Obter Dados (Híbrido: Estado + Fetch)
    
    // CUSTOS: Vem do objeto fixo
    const unitCosts = UNIT_COSTS; 

    // TROPAS NA ALDEIA (Atuais): Vem do 'state_extractor.cjs'
    if (!gameState.scavengeInfo || !gameState.scavengeInfo.unit_counts_home) {
        console.warn(`[Recruitment-${accountId}] Falha ao obter tropas atuais (scavengeInfo.unit_counts_home) do gameState. Pulando.`);
        return null;
    }
    const troopsHome = gameState.scavengeInfo.unit_counts_home;
    
    // (v40) TROPAS COLETANDO: Calculado do 'state_extractor.cjs'
    const troopsScavenging = calculateScavengingTroops(gameState.scavengeInfo.options);

    // TROPAS EM FILA/PRODUÇÃO: Precisamos buscar o HTML da 'screen=train' (v33)
    sendStatus('EM_EXECUÇÃO', 'Verificando fila de recrutamento (fetch)...');
    
    const getRefererUrl = page.url(); 
    const url = `/game.php?village=${villageId}&screen=train`; 

    const htmlContent = await page.evaluate(async ({ url, referer }) => {
         try {
             const res = await fetch(url, {
                 method: 'GET',
                 headers: {
                     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                     'TribalWars-Ajax': '1',
                     'X-Requested-With': 'XMLHttpRequest',
                     'Referer': referer 
                 }
             });
             if (!res.ok) return { error: `Network error (GET): ${res.statusText}` };
             
             const contentType = res.headers.get("content-type");
             if (contentType && contentType.includes("application/json")) {
                 const jsonData = await res.json();
                 return jsonData.content; 
             } else {
                 return await res.text(); 
             }
         } catch (e) {
             return { error: `Falha ao buscar ${url}: ${e.message}` };
         }
    }, { url: url, referer: getRefererUrl });

    if (typeof htmlContent !== 'string' || (htmlContent && htmlContent.error)) {
         throw new Error(htmlContent.error || 'Resposta da tela de recrutamento (screen=train) veio vazia.');
    }
    
    // (v39) Agora fazemos o parse do HTML (Fila + Produção)
    const { units: queuedTroops, lengths: queueLengths } = parseRecruitmentQueue(htmlContent);
    
    // --- (v40) FIM DA CORREÇÃO ---
    
    try {
         // --- 4. Calcular "Déficit" (O que falta) ---
         const deficit = {};
         let needsRecruiting = false;
         
         console.log(`[Recruitment-${accountId}] Fila (Itens Esperando): Quartel(${queueLengths.barracks}), Estábulo(${queueLengths.stable}), Oficina(${queueLengths.garage}).`);
         
         for (const unitId of RECRUITABLE_UNITS) {
             const target = targetTemplate[unitId] || 0;
             if (target === 0) continue; 
             
             // (v40) Soma (Tropas em Casa) + (Tropas Coletando) + (Tropas em Fila/Produção)
             const home = troopsHome[unitId] || 0;
             const scavenging = troopsScavenging[unitId] || 0;
             const queued = queuedTroops[unitId] || 0;
             const totalEffective = home + scavenging + queued;
             const diff = target - totalEffective;
             
             if (diff > 0 && unitCosts[unitId] && unitCosts[unitId].pop > 0) { 
                 
                 // --- (v33) REGRA MÁX 2 ITENS ---
                 const building = UNIT_BUILDING_MAP[unitId];
                 if (building && queueLengths[building] >= MAX_QUEUE_PER_BUILDING) {
                     console.log(`[Recruitment-${accountId}] Déficit de '${unitId}' (falta ${diff}), mas a fila de '${building}' está cheia (${queueLengths[building]}/${MAX_QUEUE_PER_BUILDING}). Pulando esta unidade.`);
                     continue; 
                 }
                 // --- FIM DA REGRA (v33) ---
                 
                 deficit[unitId] = diff;
                 needsRecruiting = true;
                 
             } else if (diff > 0 && (!unitCosts[unitId] || unitCosts[unitId].pop === 0)) {
                 console.warn(`[Recruitment-${accountId}] Template quer recrutar '${unitId}', mas os custos fixos não foram definidos (ou pop=0). Pulando esta unidade.`);
             }
         }
         
         if (!needsRecruiting) {
             console.log(`[Recruitment-${accountId}] Alvo de tropas atingido (ou filas cheias). Pulando.`);
             return null;
         }
         
         // --- 5. Calcular "Excedente" (Recursos Gastáveis) ---
         const r = gameState.resources; 
         const p = gameState.population; 
         
         const maxStorage = r.storage.max;
         const buffer = maxStorage * RESOURCE_BUFFER_PERCENTAGE; 
         const spendableResources = {
             wood: Math.max(0, r.wood - buffer),
             clay: Math.max(0, r.clay - buffer), 
             iron: Math.max(0, r.iron - buffer),
             pop: Math.max(0, p.max - p.current) 
         };
         
         // --- 6. Calcular "Lote Proporcional" (O Cérebro) ---
         const batchToRecruit = calculateProportionalBatch(deficit, spendableResources, unitCosts);

         if (Object.keys(batchToRecruit).length === 0) {
             console.log(`[Recruitment-${accountId}] Déficit encontrado, mas sem recursos/população (considerando buffer de ${RESOURCE_BUFFER_PERCENTAGE*100}%). Pulando.`);
             return null;
         }
         
         console.log(`[Recruitment-${accountId}] Alvo:`, JSON.stringify(targetTemplate));
         console.log(`[Recruitment-${accountId}] Faltam (Déficit):`, JSON.stringify(deficit));
         console.log(`[Recruitment-${accountId}] Recrutando (Lote):`, JSON.stringify(batchToRecruit));

         // --- 7. Enviar Ordem (Endpoint 2: POST ajaxaction=train) ---
         const payload = {};
         for (const unitId in batchToRecruit) {
             payload[`units[${unitId}]`] = batchToRecruit[unitId];
         }
         payload['h'] = csrfToken;
         
         const recruitUrl = `/game.php?village=${villageId}&screen=train&ajaxaction=train&mode=train`;
         
         sendStatus('EM_EXECUÇÃO', `Enviando ordem de recrutamento... (${Object.keys(batchToRecruit).length} tipos)`);
         
         // (v34) O 'Referer' para o POST deve ser a URL ABSOLUTA da 'screen=train'.
         const baseUrlMatch = getRefererUrl.match(/^(https?:\/\/[^\/]+)/);
         if (!baseUrlMatch) {
            throw new Error('Não foi possível extrair a URL base do Referer (screen=main).');
         }
         const baseUrl = baseUrlMatch[1]; 
         const postRefererUrl = baseUrl + url; 

         const recruitResponse = await page.evaluate(async ({ url, payload, referer }) => {
             try {
                 const body = new URLSearchParams(payload).toString();
                 const res = await fetch(url, {
                     method: 'POST',
                     headers: {
                         'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                         'Accept': 'application/json, text/javascript, */*',
                         'TribalWars-Ajax': '1',
                         'X-Requested-With': 'XMLHttpRequest',
                         'Referer': referer 
                     },
                     body: body
                 });
                 if (!res.ok) return { error: `Network error (POST): ${res.statusText}` };
                 
                 const text = await res.text();
                 if (text.startsWith('<')) {
                     return { error: `Falha ao fazer POST ${url}: O servidor respondeu com HTML/XML (provavelmente erro de 'Referer' ou sessão), não JSON.` };
                 }
                 return JSON.parse(text); 
                 
             } catch (e) {
                 return { error: `Falha ao fazer POST ${url}: ${e.message}` };
             }
         }, { url: recruitUrl, payload: payload, referer: postRefererUrl }); 

         if (recruitResponse.error) {
             throw new Error(recruitResponse.error);
         }

         // (v37) VERIFICAÇÃO DE SUCESSO DE ROBUSTEZ MÁXIMA
         if (recruitResponse.success) {
             console.log(`[Recruitment-${accountId}] Recrutamento iniciado com sucesso (Confirmado por 'success: true').`);
             
             if (recruitResponse.msg) {
                 sendStatus('EM_EXECUÇÃO', `Recrutamento OK: ${recruitResponse.msg.substring(0, 50)}`);
             } else {
                 sendStatus('EM_EXECUÇÃO', `Recrutamento iniciado (${Object.keys(batchToRecruit).length} tipos).`);
             }
             
             if (recruitResponse.game_data && recruitResponse.game_data.village) {
                 return recruitResponse.game_data.village;
             }
             
             return null; 

         } else {
              console.warn(`[Recruitment-${accountId}] Servidor recusou o recrutamento (Falha Real):`, recruitResponse.msg || 'Sem mensagem');
              return null;
         }

    } catch (error) {
         console.error(`[Recruitment-${accountId}] Erro fatal no módulo de recrutamento:`, error);
         sendStatus('FALHA!', `Erro no recrutamento: ${error.message.split('\n')[0]}`);
         return null;
    }
}

module.exports = { execute };